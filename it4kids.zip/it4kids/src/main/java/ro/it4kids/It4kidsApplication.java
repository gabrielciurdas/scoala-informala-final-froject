package ro.it4kids;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class It4kidsApplication {

	public static void main(String[] args) {
		SpringApplication.run(It4kidsApplication.class, args);
	}
}
